<!-- .slide: data-background-image="https://images.pexels.com/photos/17323801/pexels-photo-17323801.jpeg" data-background-size="cover" data-background-opacity="0.4" -->


<div class="glass-box">
    <h1>Perspectiva Histórica dos Bancos de Dados</h1>
</div>

---

## Hierarquia do Processamento de Dados

A evolução do processamento de dados segue uma progressão hierárquica baseada no valor agregado e na inteligência aplicada:

1. Dado: A unidade básica, representando valores ou fatos, servindo como matéria-prima para informações.

2. Informação: Dados processados e organizados para responder a perguntas, atendendo a necessidades específicas de usuários.

3. Conhecimento: Envolve a interpretação dos dados, trazendo padrões; pode ser indutivo (descoberta de regras novas) ou dedutivo (geração de informações a partir de regras lógicas).

4. "Sabedoria": O estágio final, onde o conhecimento é aplicado por especialistas para tomar decisões estratégicas, utilizando ferramentas como OLAP e sistemas de apoio à decisão.

A necessidade de armazenar e recuperar informações de forma eficiente é um desafio central na computação. Antes dos bancos de dados modernos, as abordagens de gerenciamento de dados, apresentavam limitações importantes, revelando a complexidade de gerenciar dados de maneira consistente e escalável.

Antes da computação, a gestão de dados dependia inteiramente de processos manuais. As informações eram registradas em fichas de papel, organizadas em pastas e armazenadas em arquivos físicos. Essa estrutura tornava a extração de dados extremamente lenta, pois o acesso dependia da localização geográfica dos documentos, exigindo um esforço operacional imenso e dispendioso.

Os primeiros arquivos digitais surgiram como uma tentativa de modernização, mas herdaram as limitações do mundo físico. Cada programa manipulava seus próprios arquivos isolados. A falta de integração mantinha a estrutura rígida, funcionando apenas como uma versão digitalizada das pastas físicas.

No início da era computacional, o código do programa e a estrutura de dados eram indissociáveis. Os sistemas gravavam informações em discos utilizando formatos proprietários e fechados.

Essa arquitetura criava uma barreira técnica: se um programa não conhecesse a estrutura exata dos dados, ele era incapaz de interpretá-los, impedindo o compartilhamento de informações.

O Processamento Tradicional de Arquivos predominava, onde a definição dos dados fazia parte do código das aplicações. Cada aplicação gerava e implementava seus arquivos de dados, resultando em um ecossistema fragmentado.

As principais desvantagens dessa abordagem eram:

- Redundância de Dados: Diferentes usuários mantinham arquivos separados com informações comuns e relacionadas, como universidades que duplicavam registros acadêmicos e financeiros, causando desperdício de espaço e esforço.

- Dependência entre Dados e Aplicações: Modificações na estrutura de um arquivo exigiam alterações em todo o código, tornando os sistemas frágeis e limitando inovações.

- Inconsistência de Dados: A duplicação aumentava o risco de inconsistências, pois atualizações em um departamento poderiam não refletir em outro, comprometendo a confiabilidade das informações.

A falta de independência entre dados e aplicações transformava qualquer evolução tecnológica em um desafio logístico. Alterar um simples campo no banco de dados obrigava a reescrita de todos os programas que o acessavam.

Esse cenário resultava em redundâncias massivas e inconsistências graves, onde garantir a unicidade e a integridade da informação era o maior obstáculo para o crescimento das operações digitais.

A solução para a rigidez dos sistemas veio com a criação de uma camada de abstração intermediária que separou a lógica do programa da estrutura física dos arquivos. Com essa separação, alterações estruturais passaram a ser realizadas de forma centralizada, sem impactar o código das aplicações finais.

A evolução da camada intermediária culminou no desenvolvimento dos Sistemas Gerenciadores de Banco de Dados (SGBD).

## A revolução relacional

O modelo relacional representou o primeiro grande salto na abstração do modelo lógico da implementação física, uma ideia revolucionária na época. Sua principal inovação foi a separação entre a representação lógica dos dados e seu armazenamento físico, inaugurando uma era de independência de dados. Pela primeira vez, as aplicações podiam interagir com os dados com base em seu significado e estrutura lógica, sem precisar conhecer os detalhes de sua implementação no disco.

O modelo é construído sobre alguns componentes fundamentais, baseados na teoria dos conjuntos:

- Relação: tabela com linhas e colunas, semelhante a uma tabela de valores.
- Tupla: linha da tabela, representando um único registro ou fato.
- Atributo: coluna da tabela, representando uma propriedade de um registro.
- Domínio: conjunto de valores permitidos para um determinado atributo.

A base teórica do modelo é a Álgebra Relacional, uma coleção de operações formais utilizadas para manipular relações.

Um dos pilares do modelo relacional é a garantia da integridade dos dados por meio de restrições. As chaves desempenham um papel central nesse processo (Chave Primária e Chave Estrangeira)

## SQL

Para a implementação prática, a SQL (Structured Query Language) tornou-se a linguagem padrão para banco de dados. A SQL fornece comandos para manipulação de dados (DML), e para definição de dados (DDL).

Estrategicamente, a SQL tornou-se mais do que uma linguagem; foi um padrão universal que desvinculou a lógica de negócios das implementações de fornecedores específicos. Essa padronização da linguagem SQL permite que as empresas desenvolvam suas aplicações sem ficarem presas a um único fabricante de software, garantindo que o código e a lógica criados permaneçam válidos mesmo que a infraestrutura mude.

## Projeto de banco de dados

O modelo relacional exige que o esquema do banco de dados seja projetado cuidadosamente antes da inserção das informações. Ele utiliza de dados estruturados, sendo informações que são representadas e armazenadas em um formato estrito e predefinido, no qual cada registro segue a mesma estrutura que os demais.

O projeto de esquemas relacionais tem como um de seus objetivos principais minimizar a redundância de informações e evitar as "anomalias de atualização" (inserção, exclusão e modificação).

As anomalias de atualização são problemas que ocorrem em bancos de dados relacionais quando as tabelas (relações) possuem redundância de informações devido a um projeto de esquema inadequado ou falta de normalização. Essas falhas geram dificuldades na manutenção da integridade e consistência dos dados, exigindo atualizações desnecessárias e podendo causar perda de informações.

A normalização é o processo formal utilizado para decompor esquemas em estruturas menores e mais bem estruturadas para atingir esse objetivo.

## SGBDs

O SGBD (Sistema Gerenciador de Banco de Dados) é uma coleção de programas que permite aos usuários criar, manter e manipular um banco de dados computadorizado, facilitando os processos de definição, construção e compartilhamento de dados entre diversas aplicações.

Resumindo as relações:

Modelo Relacional representa a base teórica e estrutural onde os dados são organizados em relações (tabelas) compostas por linhas (tuplas) e colunas (atributos).

SQL é a linguagem de consulta padrão utilizada para interagir com SGBDs que seguem o modelo relacional.

SGBD atua como o motor de software que implementa o modelo de dados e processa os comandos SQL. Exemplos: Oracle, MySQL, PostgreSQL, Microsoft SQL Server.

Os SGBDs relacionais promovem a consistência por meio de transações atômicas (atomicidade), que devem ser concluídas em sua totalidade ou não realizadas. Se uma transação falhar, todas as operações são revertidas, evitando efeitos parciais (bagunça) no banco de dados.

### O que o Modelo Relacional resolveu?

- Independência entre Dados e Programas: A introdução de um catálogo de metadados permite armazenar a estrutura dos dados separadamente das aplicações, promovendo a evolução da estrutura das tabelas sem necessidade de reescrever os programas.

- Eliminação de Redundâncias e Anomalias: A normalização de bancos de dados organiza atributos em tabelas para reduzir a duplicação de informações, prevenindo anomalias de inserção, exclusão e modificação.

- Consulta Declarativa com SQL: A SQL, com sua sintaxe clara e abordagem declarativa, permite ao usuário especificar o que deseja recuperar, enquanto o SGBD cuida da melhor forma de acesso físico aos dados, representando um grande avanço em relação aos modelos de acesso navegacional anteriores.

## Evolução NoSQL pós-relacional

O modelo relacional continua sendo a espinha dorsal de inúmeros sistemas transacionais críticos, como ERPs e CRMs, onde a consistência dos dados, a integridade referencial e as transações atômicas são prioridades não negociáveis.

Com a explosão de dados impulsionada pela internet, as características que tornaram o modelo relacional eficaz (como a consistência e a normalização) tornaram-se gargalos. O modelo relacional falha em lidar com os " Três Vs do
Big Data " (Volume, Variedade e Velocidade):

- Não suporta o volume massivo de dados.
- Falha em lidar com a variedade de dados complexos e semiestruturados (XML, JSON embutem os dados em sua própria estrutura, não são rígidos).
- Fica lento e trava no processamento em tempo real por ser muito rígido e difícil de expandir.

Em resposta aos desafios do modelo relacional, surgiu a era pós-relacional, muitas vezes representada pelo movimento NoSQL.

NoSQL refere-se a uma categoria de sistemas de gerenciamento de banco de dados que não utilizam o modelo relacional tradicional. Esses bancos de dados são projetados para lidar com grandes volumes de dados, dados semiestruturados ou não estruturados, e para atender a requisitos de escalabilidade e flexibilidade que os bancos de dados relacionais muitas vezes não conseguem.

Os bancos de dados NoSQL são classificados em quatro categorias principais, cada uma adequada a diferentes tipos de dados e necessidades:

- Armazenamento de Documentos: MongoDB, CouchDB
- Armazenamento de Chave-Valor: Redis, DynamoDB
- Armazenamento em Colunas: Cassandra, HBase
- Bancos de Dados de Grafos: Neo4j, ArangoDB

Finalmente, as plataformas Low-Code/No-Code como o Xano, representam a mais recente camada de abstração dos bancos de dados, focada em capacitar usuários de negócios para resolver seus próprios problemas rapidamente, muitas vezes escondendo completamente a complexidade do banco de dados subjacente.

A criação e operação de banco de dados é simplificada nessa plataforma, e utilizá-la é algo parecido com o uso planilhas do google. Mas ainda assim é necessário compreender definições fundamentais a todos os bancos de dados.

Há diversos tipos de banco de dados já criados, mas não importa o tipo, todos compartilham propriedades fundamentais:

- Representação do "Mini-mundo": Cada banco representa algum aspecto da realidade, cujas mudanças devem ser refletidas na base de dados.
- Coleção Lógica: São conjuntos de dados logicamente inter-relacionados e coerentes, projetados para um propósito específico e para um grupo definido de usuários.
- Abstração de Dados: Fornecem uma visão conceitual que oculta detalhes técnicos de como os dados são armazenados no computador.
- Gerenciamento por SGBD: São operados por um Sistema Gerenciador de Banco de Dados, que facilita os processos de definição, construção, manipulação e compartilhamento das informações.